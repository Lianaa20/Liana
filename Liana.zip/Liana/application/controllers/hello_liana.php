<?php

class Hello_liana extends CI_Controller {
 public function index() {
   $this->load->model('m_liana');
   $data['siswibc']= $this->m_liana->get_data();

  $this->load->view('dashboard',$data);
  }

}

?>