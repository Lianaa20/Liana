<?php

class Kelola_buku extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('model_barang');
        
}
    
    public function index() {
        $data['barang'] = $this->model_barang->get_data()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('kelola_buku', $data);
        $this->load->view('templates/footer');
    }

    public function tambah() {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('tambah');
        $this->load->view('templates/footer');
    }

    public function proses_tambah() { 
        $nama_brg = $this->input->post('nama_brg');
        $keterangan = $this->input->post('keterangan');
        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama_brg' => $nama_brg,
            'keterangan' => $keterangan,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
        );

        $this->model_barang->input_data($data, 'tb_barang');
        redirect('Kelola_buku'); 
    }

    public function dashboard() {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('v_liana'); 
        $this->load->view('templates/footer');
    }
 

public function edit($id) {
    $where = array('id_brg' => $id);
    $data['barang'] = $this->model_barang->edit_data($where, 'tb_barang')->result();
    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('edit', $data);
    $this->load->view('templates/footer');
}

public function update() {
    $id = $this->input->post('id_brg');
    $nama_brg = $this->input->post('nama_brg');
    $keterangan = $this->input->post('keterangan');
    $kategori = $this->input->post('kategori');
    $harga = $this->input->post('harga');
    $stok = $this->input->post('stok');
    

    $data = array(
        'nama_brg' => $nama_brg,
        'keterangan' => $keterangan,
        'kategori' => $kategori,
        'harga' => $harga,
        'stok' => $stok
    );

    $where = array(
        'id_brg' => $id
    );

    $this->model_barang->update_data($where, $data, 'tb_barang');
    redirect('kelola_buku');
}

public function hapus($id) {
    $where = array('id_brg' => $id);
    $this->model_barang->hapus_data($where, 'tb_barang');
    redirect('Kelola_buku');
}
}
     