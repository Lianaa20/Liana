<div class="main-content container-fluid">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h5>Form tambah buku</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo base_url('index.php/Kelola_buku/proses_tambah');?>" method="post">
                    <div class="mb-3">
                        <label for="nama_brg" class="form-label">Nama Barang</label>
                        <input type="text" name="nama_brg" class="form-control" id="nama_brg" required>
                    </div>
                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <input type="text" name="keterangan" class="form-control" id="keterangan" required>
                    </div>
                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" name="kategori" class="form-control" id="kategori" required>
                    </div>
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <input type="number" name="harga" class="form-control" id="harga" required>
                    </div>
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <input type="number" name="stok" class="form-control" id="stok" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
    </div>
</div>