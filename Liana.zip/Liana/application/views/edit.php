<div class="main-content container-fluid">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h5>Form Edit Buku</h5>
            </div>
            <div class="card-body">
                <?php foreach ($barang as $brg) { ?>
                    <form action="<?php echo base_url('index.php/Kelola_buku/update'); ?>" method="post">
                        <input type="hidden" name="id_brg" value="<?php echo $brg->id_brg; ?>">
                        <div class="mb-3">
                            <label for="nama_brg" class="form-label">Nama Barang</label>
                            <input type="text" name="nama_brg" class="form-control" id="nama_brg" value="<?php echo $brg->nama_brg ?>">
                        </div>
                        <div class="mb-3">
                            <label for="keterangan" class="form-label">Keterangan</label>
                            <input type="text" name="keterangan" class="form-control" id="keterangan" value="<?php echo $brg->keterangan ?>">
                        </div>
                        <div class="mb-3">
                            <label for="kategori" class="form-label">Kategori</label>
                            <input type="text" name="kategori" class="form-control" id="kategori" value="<?php echo $brg->kategori ?>">
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="text" name="harga" class="form-control" id="harga" value="<?php echo $brg->harga ?>">
                        </div>
                        <div class="mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="text" name="stok" class="form-control" id="stok" value="<?php echo $brg->stok ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Update Barang</button>
                        <a href="<?php echo base_url('index.php/Kelola_buku'); ?>" class="btn btn-secondary">Batal</a>
                    </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>