<div class="main-content container-fluid">
    <div class="container-fluid">
        <div class="page-title">
            <h3>Booklynn</h3>
            <p class="text-subtitle text-muted">Langkah Kecil Menuju Pengetahuan Besar</p>
        </div>
        <section class="section">
            </section>
        <a href="<?php echo base_url('index.php/Kelola_buku/tambah'); ?>" class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#tambah_buku"><i class="fas fa-plus fa-sm"></i> Tambah Buku</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Keterangan</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            foreach ($barang as $b) : ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $b->nama_brg ?></td>
                    <td><?= $b->keterangan ?></td>
                    <td><?= $b->kategori ?></td>
                    <td><?= $b->harga ?></td>
                    <td><?= $b->stok ?></td>
                    <td>
    
    <a href="<?= base_url('index.php/Kelola_buku/detail/'.$b->id_brg); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-eye"></i>
    </a>
   
    <a href="<?= base_url('index.php/Kelola_buku/edit/'.$b->id_brg); ?>" class="btn btn-warning btn-sm">
        <i class="fas fa-edit"></i>
    </a>
    <a href="<?= base_url('index.php/Kelola_buku/hapus/'.$b->id_brg); ?>" 
       class="btn btn-danger btn-sm" 
       onclick="return confirm('Yakin ingin menghapus?');">
        <i class="fas fa-trash"></i>
    </a>
</td>
</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
                </div>
            </main>