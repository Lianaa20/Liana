   <div class="layer"></div>
    <a class="skip-link sr-only" href="#skip-target">Skip to content</a>
    <div class="page-flex">
        <aside class="sidebar">
            <div class="sidebar-start">
                <div class="sidebar-head">
                    <a href="<?php echo base_url();?>" class="logo-wrapper" title="store">
                        <span class="sr-only">Toggle menu</span>
                        <span class="icon logo" aria-hidden="true"></span>
                        <div class="logo-text">
                            <span class="logo-title">Toko online</span>
                            <span class="logo-subtitle">Buku</span>
                        </div>
                    </a>
                    <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                        <span class="sr-only">Toggle menu</span>
                        <span class="icon menu-toggle" aria-hidden="true"></span>
                    </button>
                </div>
                <div class="sidebar-body">
                    <ul class="sidebar-body-menu">
                        <li>
                            <a class="active" href="<?php echo base_url('index.php/admin'); ?>">
  <span class="icon home" aria-hidden="true"></span>Dashboard
</a>
                </li>
               <li>
                            <a class="active" href="<?php echo base_url('index.php/Kelola_buku'); ?>"><span class="icon edit" aria-hidden="true"></span>Data Buku</a>
                </li>               
              <li>
<a class="active" href=""<?php echo base_url('index.php/Kelola_buku'); ?>"><span class="icon folder" aria-hidden="true"></span>Kategori</a>
                </li>
               <li>
                            <a class="active" href="<?php echo base_url('index.php/Kelola_buku'); ?>"><span class="icon edit" aria-hidden="true"></span>Laporan</a>
                </li>               
              <li>
                            
                   <ul class="cat-sub-menu">
                        <li>
                                                           
                    </div>
            </div>
            <div class="sidebar-footer">
                <a href="##" class="sidebar-user">
                    <span class="sidebar-user-img">
                        <picture>
                            <source srcset="<?php echo base_url();?>assets/img/avatar/avatar-illustrated-04.webp" type="image/webp">
                            <img src="<?php echo base_url();?>assets/img/avatar/avatar-illustrated-01.png" alt="User name">
                        </picture>
                    </span>
                    <div class="sidebar-user-info">
                        <span class="sidebar-user__title">Sesi Lianaa.</span>
                        <span class="sidebar-user__subtitle">Shop owner</span>
                    </div>
                </a>
            </div>
        </aside>
        <div class="main-wrapper">
            <nav class="main-nav--bg">
                <div class="container main-nav">
                    <div class="main-nav-start">
                        <div class="search-wrapper">
                            <i data-feather="search" aria-hidden="true"></i>
                            <input type="text" placeholder="Enter keywords ..." required>
                        </div>
                    </div>
                    <div class="main-nav-end">
                        <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                            <span class="sr-only">Toggle menu</span>
                            <span class="icon menu-toggle--gray" aria-hidden="true"></span>
                        </button>
                        <div class="nav-user-wrapper">
                            <button href="##" class="nav-user-btn dropdown-btn" title="My profile" type="button">
                                <span class="sr-only">My profile</span>
                                <span class="nav-user-img">
                                    <picture>
                                        <source srcset="<?php echo base_url();?>assets/img/avatar/avatar-illustrated-04.webp" type="image/webp">
                                        <img src="<?php echo base_url();?>assets/img/avatar/avatar-illustrated-02.png" alt="User name">
                                    </picture>
                                </span>
                            </button>
                            <ul class="users-item-dropdown nav-user-dropdown dropdown">
                                <li><a href="##">
                                        <i data-feather="user" aria-hidden="true"></i>
                                        <span>Profile</span>
                                    </a></li>
                                <li><a href="##">
                                        <i data-feather="settings" aria-hidden="true"></i>
                                        <span>Account settings</span>
                                    </a></li>
                                <li><a class="danger" href="##">
                                        <i data-feather="log-out" aria-hidden="true"></i>
                                        <span>Log out</span>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>